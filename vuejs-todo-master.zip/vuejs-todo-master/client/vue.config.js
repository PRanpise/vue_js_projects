module.exports = {
  publicPath: '/vuejs-todo/'
}