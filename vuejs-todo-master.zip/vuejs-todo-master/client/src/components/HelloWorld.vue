<template>
	<div class="ani-slideInDown text-center">
		<h1>{{ msg }}</h1>
	</div>
</template>

<script>
	export default {
		name: 'HelloWorld',
		props: {
			msg: String
		}
	}
</script>

