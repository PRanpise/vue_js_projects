<template>
	<div class="ani-slideInDown text-center">
		<h2 class="fs-h2">
			Duong Dieu Phap
		</h2>

		<p>
			<a href="https://github.com/d2phap/vuejs-todo" rel="noopener noreferer">
				https://github.com/d2phap/vuejs-todo
			</a>
		</p>
	</div>
</template>
